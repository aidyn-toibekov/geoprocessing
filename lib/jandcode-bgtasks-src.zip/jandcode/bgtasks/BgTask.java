package jandcode.bgtasks;

import jandcode.app.*;
import jandcode.bgtasks.impl.*;

/**
 * Задача
 */
public abstract class BgTask extends CompRt {

    /**
     * В очереди. Ожидает выполнения
     */
    public static final int STATUS_QUE = 0;

    /**
     * Выполняется
     */
    public static final int STATUS_RUNNED = 1;

    /**
     * Выполнена
     */
    public static final int STATUS_COMPLETED = 2;

    private String id;
    private Exception exception;
    private Thread thread;
    private int status;
    private long createdTime;
    private long lastCompletedTime;
    private long liveCompletedTime;

    private boolean enabled = true;

    private long period;
    private long delay = -1;

    private BgTasksLogger logger = new BgTasksLoggerDefault();

    public BgTask() {
        createdTime = System.currentTimeMillis();
    }

    /**
     * id задачи
     */
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * Выполнение закончилось с этой ошибкой
     */
    public Exception getException() {
        return exception;
    }

    public void setException(Exception exception) {
        this.exception = exception;
    }

    /**
     * Если запущена, то в каком потоке
     */
    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        if (status == STATUS_COMPLETED) {
            lastCompletedTime = System.currentTimeMillis();
            if (isPeriodical()) {
                // если задача периодическая, то она никогда не заканчивается
                status = STATUS_QUE;
            }
        }
        this.status = status;
    }

    /**
     * В очереди
     */
    public boolean isQue() {
        return status == STATUS_QUE;
    }

    /**
     * Выполняется
     */
    public boolean isRunned() {
        return status == STATUS_RUNNED;
    }

    /**
     * Выполнена
     */
    public boolean isCompleted() {
        return status == STATUS_COMPLETED;
    }

    /**
     * Время последнего изменения статуса на completed.
     * 0 - еще небыло изменения.
     */
    public long getLastCompletedTime() {
        return lastCompletedTime;
    }

    /**
     * Время в милисекундах, которое задача будет находится в completed в ожидании,
     * когда ее результаты кому-то понадобятся. По умолчанию - 0.
     */
    public long getLiveCompletedTime() {
        return liveCompletedTime;
    }

    public void setLiveCompletedTime(long liveCompletedTime) {
        this.liveCompletedTime = liveCompletedTime;
    }

    /**
     * Время создания задачи
     */
    public long getCreatedTime() {
        return createdTime;
    }

    /**
     * Разрешена ли задача. Если запрещена -
     * она просто удаляется из очереди без разговоров.
     */
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * Периодическая задача.
     * Период выполнения задачи в милисекундах.
     */
    public long getPeriod() {
        return period;
    }

    public void setPeriod(long period) {
        this.period = period;
    }

    /**
     * Периодическая задача.
     * задержка перед первым выполнением.
     * Если явно не задано - равно period.
     */
    public long getDelay() {
        if (delay < 0) {
            return getPeriod();
        }
        return delay;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    //////

    /**
     * true - задача периодическая
     */
    public boolean isPeriodical() {
        return getPeriod() > 0;
    }

    /**
     * logger для задачи.
     */
    public BgTasksLogger getLogger() {
        return logger;
    }

    //////

    /**
     * Реализация выполнения задачи
     */
    public void run() throws Exception {

    }
}

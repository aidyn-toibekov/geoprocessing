package jandcode.bgtasks;

import java.util.*;

/**
 * Контейнер для информации о текущем состоянии очереди
 */
public class BgTasksInfo {

    private List<BgTask> que = new ArrayList<BgTask>();
    private List<BgTask> runned = new ArrayList<BgTask>();
    private List<BgTask> completed = new ArrayList<BgTask>();

    /**
     * Задачи в очереди
     */
    public List<BgTask> getQue() {
        return que;
    }

    /**
     * Запущенные задачи
     */
    public List<BgTask> getRunned() {
        return runned;
    }

    /**
     * Выполненные задачи
     */
    public List<BgTask> getCompleted() {
        return completed;
    }

}

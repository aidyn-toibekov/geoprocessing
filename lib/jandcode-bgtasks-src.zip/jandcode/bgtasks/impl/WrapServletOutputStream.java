package jandcode.bgtasks.impl;

import javax.servlet.*;
import java.io.*;

public class WrapServletOutputStream extends ServletOutputStream {

    private ByteArrayOutputStream _outStream = new ByteArrayOutputStream();

    public void write(int b) throws IOException {
        _outStream.write(b);
    }

    public byte[] getBytes() {
        return _outStream.toByteArray();
    }

}
package jandcode.bgtasks.impl;

import jandcode.web.*;

public class BgTaskDummyAction extends WebAction {
    protected void onExec() throws Exception {
    }
}

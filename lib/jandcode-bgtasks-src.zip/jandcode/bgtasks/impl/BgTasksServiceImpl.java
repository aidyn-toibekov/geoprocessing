package jandcode.bgtasks.impl;

import jandcode.bgtasks.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import org.apache.commons.logging.*;

import java.util.*;

public class BgTasksServiceImpl extends BgTasksService {

    protected static Log log = LogFactory.getLog(BgTasksService.class);

    private TaskHolder tasks = new TaskHolder();
    private List<BgTasksChoicer> choicers = new ArrayList<BgTasksChoicer>();
    private int maxThreads = 10;
    private BgTasksErrorHandler errorHandler;

    //
    private BgTasksLogger dummyLogger = new BgTasksLoggerDummy();

    // таймер
    private boolean enabled = true;
    private Timer timer;
    private long delay = 100;
    private long period = 100;


    /**
     * Поток для запуска задач
     */
    class RunThread extends Thread {

        BgTask task;

        public void setTask(BgTask task) {
            this.task = task;
        }

        public void run() {
            try {
                log.info("Start BgTask id=" + task.getId());
                task.setThread(this);
                task.getLogger().clear();
                task.run();
            } catch (Exception e) {
                task.setException(e);
                getErrorHandler().handleError(e);
            } finally {
                log.info("Stop BgTask id=" + task.getId());
                task.setThread(null);
                tasks.moveToCompleted(task);
            }
        }

    }

    /**
     * Таймер. Запуск очередного шага фоновых процессов.
     */
    public class BgtTimerTask extends TimerTask {

        public void run() {
            try {
                doStep();
            } catch (Exception e) {
                getErrorHandler().handleError(e);
            }
        }

    }

    class ComparatorChoicers implements Comparator<BgTasksChoicer> {
        public int compare(BgTasksChoicer o1, BgTasksChoicer o2) {
            Integer i1 = o1.getWeight();
            Integer i2 = o2.getWeight();
            int n = i1.compareTo(i2);
            if (n == 0) {
                i1 = o1.getIndex();
                i2 = o2.getIndex();
                n = i1.compareTo(i2);
            }
            return n;
        }
    }

    //////

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);

        //
        Rt x1 = rt.findChild("choicer");
        if (x1 != null) {
            for (Rt x2 : x1.getChilds()) {
                BgTasksChoicer z = (BgTasksChoicer) getApp().getObjectFactory().create(x2);
                choicers.add(z);
            }
        }
        Collections.sort(choicers, new ComparatorChoicers());

        // error handler
        x1 = rt.getChild("errorhandler/default");
        errorHandler = (BgTasksErrorHandler) getApp().getObjectFactory().create(x1);

        //
        x1 = rt.findChild("bgtask");
        if (x1 != null) {
            for (Rt x2 : x1.getChilds()) {
                BgTask z = (BgTask) getApp().getObjectFactory().create(x2);
                addTask(z);
            }
        }

    }

    public void addTask(BgTask task) {
        task.setApp(getApp());
        tasks.add(task);
    }

    public void removeTask(BgTask task) {
        Thread th = task.getThread();
        if (th != null) {
            // для dao проверено: error вызывается корректно
            th.stop(new XError("interrupted"));
        }
        tasks.remove(task);
    }

    public BgTask getTask(String id) {
        BgTask t = tasks.find(id);
        if (t == null) {
            throw new XError("Task not found {0}", id);
        }
        return t;
    }

    public BgTask findTask(String id) {
        return tasks.find(id);
    }

    //////

    public List<BgTasksChoicer> getChoicers() {
        return choicers;
    }

    public int getMaxThreads() {
        return maxThreads;
    }

    public void setMaxThreads(int maxThread) {
        this.maxThreads = maxThreads;
    }

    public boolean isQueEmpty() {
        return tasks.isQueEmpty();
    }

    public BgTasksInfo getTasksInfo() {
        BgTasksInfo res = new BgTasksInfo();
        tasks.grabQue(res.getQue(), res.getRunned(), res.getCompleted());
        return res;
    }

    //////

    /**
     * Выполнить один шаг по выборке и запуску следующей задачи для выполнения
     */
    protected void doStep() throws Exception {
        List<BgTask> taskQue = new ArrayList<BgTask>();
        List<BgTask> taskRunned = new ArrayList<BgTask>();
        List<BgTask> taskCompleted = new ArrayList<BgTask>();
        tasks.grabQue(taskQue, taskRunned, taskCompleted);

        // проверяем выполненые задачи на предмет удаления
        long curTime = System.currentTimeMillis();
        for (BgTask t : taskCompleted) {
            long age = curTime - t.getLastCompletedTime();
            if (age > t.getLiveCompletedTime()) {
                // задача слишком долго находится в выполненных - удаляем
                tasks.remove(t);
            }
        }

        if (taskQue.size() == 0) {
            return; // задач нет
        }

        if (taskRunned.size() >= maxThreads) {
            return; // все потоки заняты
        }

        // выбираем задачу для выполнения
        BgTask task = null;

        for (BgTasksChoicer ch : choicers) {
            task = ch.choiceNextTask(taskQue, taskRunned);
            if (task != null) {
                break; // задача выбрана
            }
        }

        if (task == null) {
            // если задача не выбрана, выбираем по другому
            for (BgTask t : taskQue) {
                boolean flag = true;
                for (BgTasksChoicer ch : choicers) {
                    flag = ch.checkTaskRun(t, taskRunned);
                    if (!flag) {
                        break; // эта задача сейчас не может быть выполнена
                    }
                }
                if (flag) {
                    task = t; // против этой задачи никто не имеет ничего против
                    break;
                }
            }
        }

        if (task == null) {
            // задача так и не выбрана
            return;
        }

        // задача имеется, условия подходящие, выполняем

        // перемещаем в список выполняющихся тут, что бы задача не попала
        // в кандидаты на выполнение при следующем цикле
        tasks.moveToRunned(task);

        // запускаем поток
        RunThread th = new RunThread();
        th.setDaemon(true); // что бы поток прекратил выполнение после выхода из основной программы
        th.setTask(task);
        th.start();

        // повторяем, чего время то терять
        doStep();
    }

    //////

    public BgTasksErrorHandler getErrorHandler() {
        return errorHandler;
    }

    public void setErrorHandler(BgTasksErrorHandler errorHandler) {
        this.errorHandler = errorHandler;
    }

    ////// таймер

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public long getDelay() {
        return delay;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    public long getPeriod() {
        return period;
    }

    public void setPeriod(long period) {
        this.period = period;
    }

    public void start() {
        stop();
        if (!isEnabled()) {
            return;
        }
        BgtTimerTask task = new BgtTimerTask();
        timer = new Timer();
        timer.schedule(task, delay, period);
    }

    public void stop() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    public void appShutdown(Object appInstance) {
        stop();
    }

    public void appStartup(Object appInstance) throws Exception {
        start();
    }

    //////

    public BgTasksLogger getLogger() {
        Thread th = Thread.currentThread();
        if (th instanceof RunThread) {
            return ((RunThread) th).task.getLogger();
        }
        return dummyLogger;
    }
}

package jandcode.bgtasks.impl;

import jandcode.bgtasks.*;

import java.util.*;

/**
 * Ничего не делающий logger.
 */
public class BgTasksLoggerDummy implements BgTasksLogger {

    public void info(String msg) {
    }

    public void put(String key, Object value) {
    }

    public Collection<String> getMsgs(boolean all) {
        return new ArrayList<String>();
    }

    public Map<String, String> getData() {
        return new HashMap<String, String>();
    }

    public void clear() {
    }

}

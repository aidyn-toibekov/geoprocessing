package jandcode.bgtasks.impl;

import jandcode.bgtasks.*;

public class BgTasksErrorHandlerDefault extends BgTasksErrorHandler {
}

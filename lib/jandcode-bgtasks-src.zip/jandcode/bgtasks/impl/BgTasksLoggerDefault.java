package jandcode.bgtasks.impl;

import jandcode.bgtasks.*;
import jandcode.utils.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * Реализация logger по умолчанию
 */
public class BgTasksLoggerDefault implements BgTasksLogger {

    private List<String> msgs = new ArrayList<String>();
    private Map<String, String> data = new ConcurrentHashMap<String, String>();
    private int lastMsg = -1;

    public void info(String msg) {
        msgs.add(msg);
    }

    public void put(String key, Object value) {
        data.put(key, UtCnv.toString(value));
    }

    public Collection<String> getMsgs(boolean all) {
        List<String> res = new ArrayList<String>();
        int start = 0;
        if (!all) {
            start = lastMsg + 1;
        }
        int size = msgs.size();
        for (int i = start; i < size; i++) {
            res.add(msgs.get(i));
        }
        if (!all) {
            lastMsg = msgs.size() - 1;
        }
        return res;
    }

    public Map<String, String> getData() {
        Map<String, String> res = new HashMap<String, String>();
        res.putAll(data);
        return res;
    }

    public void clear() {
        msgs.clear();
        data.clear();
        lastMsg = -1;
    }

}

package jandcode.bgtasks.impl;

import jandcode.bgtasks.*;

import java.util.*;

/**
 * Выбор периодических задач
 */
public class TimerBgTasksChoicer extends BgTasksChoicer {

    public BgTask choiceNextTask(Collection<BgTask> tasks, Collection<BgTask> runnedTask) throws Exception {

        long curTime = 0;
        for (BgTask t : tasks) {
            if (t.getPeriod() > 0) {
                // период задан
                if (curTime == 0) {
                    curTime = System.currentTimeMillis();
                }
                if (t.getLastCompletedTime() == 0) {
                    // еще не выполнялась
                    if (curTime - t.getCreatedTime() > t.getDelay()) {
                        return t;
                    }
                } else {
                    // уже выполнялась
                    if (curTime - t.getLastCompletedTime() > t.getPeriod()) {
                        return t;
                    }
                }
            }
        }
        return null;
    }

    public boolean checkTaskRun(BgTask task, Collection<BgTask> runnedTask) throws Exception {
        if (task.getPeriod() > 0) {
            return false; // она может быть выбрана только из общего списка!
        }
        return true;
    }

}

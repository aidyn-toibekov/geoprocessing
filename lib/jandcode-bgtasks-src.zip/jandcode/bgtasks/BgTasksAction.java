package jandcode.bgtasks;

import jandcode.utils.error.*;
import jandcode.web.*;

import java.util.*;


/**
 * action для фоновых задач
 */
public class BgTasksAction extends WebAction {

    public static final String P_TASKID = "taskId";
    public static final String P_TASKIDS = "taskIds";
    public static final String P_TASKS = "tasks";


    /**
     * Безусловно остановить задачу.
     */
    public void stop(JsonActionWrapper wrap) throws Exception {
        BgTasksService svc = getApp().service(BgTasksService.class);
        String id = getParams().getValueString(P_TASKID);
        BgTask task = svc.getTask(id);
        svc.removeTask(task);

        // success = true...
        Map res = new LinkedHashMap();
        wrap.setJson(res);
    }

    /**
     * Статус задач.
     * На входе: taskIds:[id1,id2]
     * На выходе: tasks: {id1:{status:status, logmsgs:[msgs], logdata:{data}},...}
     */
    public void status(JsonActionWrapper wrap) throws Exception {
        BgTasksService svc = getApp().service(BgTasksService.class);
        List<String> taskIds = (List<String>) UtJson.toObject(getParams().getValueString(P_TASKIDS));
        Map resStat = new HashMap();

        if (taskIds != null) {
            for (String id : taskIds) {
                Map r = new HashMap();
                r.put("status", -1);
                List logmsgs = new ArrayList();
                r.put("logmsgs", logmsgs);
                Map logdata = new HashMap();
                r.put("logdata", logdata);
                //
                BgTask task = svc.findTask(id);
                if (task != null) {
                    r.put("status", task.getStatus());
                    logmsgs.addAll(task.getLogger().getMsgs(false));
                    logdata.putAll(task.getLogger().getData());
                }
                resStat.put(id, r);
            }
        }
        //
        Map res = new LinkedHashMap();
        res.put(P_TASKS, resStat);
        wrap.setJson(res);
    }

    /**
     * Получить результат выполнения action.
     */
    public void result() throws Exception {
        BgTasksService svc = getApp().service(BgTasksService.class);
        String id = getParams().getValueString(P_TASKID);
        BgTask t = svc.getTask(id);
        if (!t.isCompleted()) {
            throw new XError("Task not completed");
        }
        if (t.getException() != null) {
            svc.removeTask(t);
            throw t.getException();
        }
        if (t instanceof ActionBgTask) {
            ((ActionBgTask) t).renderActionResult(getRequest());
            svc.removeTask(t);
        } else {
            throw new XError("Not action task");
        }
    }

}

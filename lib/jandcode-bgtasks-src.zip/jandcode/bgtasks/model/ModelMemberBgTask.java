package jandcode.bgtasks.model;

import jandcode.bgtasks.*;
import jandcode.dbm.*;

/**
 * Предок для задач, которые знают про модель.
 */
public class ModelMemberBgTask extends BgTask implements IModelLink, IModelLinkSet {

    private Model model;

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

}

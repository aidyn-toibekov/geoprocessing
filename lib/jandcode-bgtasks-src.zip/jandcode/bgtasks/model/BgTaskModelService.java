package jandcode.bgtasks.model;

import jandcode.app.*;
import jandcode.bgtasks.*;
import jandcode.dbm.*;
import jandcode.utils.rt.*;

/**
 * Сервис для подключения в модель и использование фоновых задач, которые привязаны
 * к модели.
 * <p/>
 * Задачи будут собиратся из тегов bgtask в модели.
 * Если задача унаследована от ModelMemberBgTask, то она получит ссылку на модель.
 */
public class BgTaskModelService extends ModelMember implements IActivate {


    public void activate() throws Exception {

        // регистрация задач

        Rt x = getModel().getRt().findChild("bgtask");
        if (x != null) {
            for (Rt z : x.getChilds()) {
                BgTask task = (BgTask) getModel().getObjectFactory().create(z);
                getApp().service(BgTasksService.class).addTask(task);
            }
        }

    }


}

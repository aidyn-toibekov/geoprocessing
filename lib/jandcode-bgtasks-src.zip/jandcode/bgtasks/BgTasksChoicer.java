package jandcode.bgtasks;

import jandcode.app.*;

import java.util.*;

/**
 * Выбор следующей задачи для выполнения
 */
public class BgTasksChoicer extends CompRt {

    protected int index;
    protected int weight = 50;

    /**
     * @param tasks      доступные задачи
     * @param runnedTask выполняющиеся сейчас задачи
     * @return задача из списка task, которая должна быть выполнена следующей или null,
     * если такой задачи нет
     */
    public BgTask choiceNextTask(Collection<BgTask> tasks, Collection<BgTask> runnedTask) throws Exception {
        return null;
    }

    /**
     * Задача была выбрана для выполнения. Можно ли ее выполнять?
     *
     * @param task       проверяемая задача
     * @param runnedTask выполняющиеся сейчас задачи
     * @return true - обработчику все равно, можно выполнять. false - категорически нельзя
     * выполнять
     */
    public boolean checkTaskRun(BgTask task, Collection<BgTask> runnedTask) throws Exception {
        return true;
    }

    //////

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

}

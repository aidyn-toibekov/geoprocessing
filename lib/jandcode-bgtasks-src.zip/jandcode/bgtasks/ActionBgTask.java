package jandcode.bgtasks;

import jandcode.bgtasks.impl.*;
import jandcode.utils.error.*;
import jandcode.web.*;

import javax.servlet.http.*;

/**
 * Задача по фоновому выполнению web-action
 */
public class ActionBgTask extends BgTask {

    protected WebRequest originalRequest;
    protected WrapWebRequest wrapRequest;

    public ActionBgTask() {
    }

    public ActionBgTask(WebRequest originalRequest) {
        this();
        this.originalRequest = originalRequest;
        wrapRequest = new WrapWebRequest(originalRequest);
        int z = originalRequest.getWebService().getApp().getRt().getValueInt("app/bgtasks:taskAction.liveCompletedTime", 100000);
        setLiveCompletedTime(z);
    }

    /**
     * Запрос, который должен быть выполнен
     */
    public WebRequest getRequest() {
        return wrapRequest;
    }

    public void run() throws Exception {
        // выполняем оригинальный request
        //
        WebService wsvc = getApp().service(WebService.class);
        wsvc.setRequest(wrapRequest);
        try {
            wsvc.handleRequest(wrapRequest);
        } finally {
            wsvc.setRequest(null);
        }
    }

    /**
     * Метод отображает результат работы action в указанный request
     */
    public void renderActionResult(WebRequest request) {
        if (wrapRequest == null) {
            throw new XError("run not executed");
        }
        //
        WrapHttpServletResponse wResp = (WrapHttpServletResponse) wrapRequest.getHttpResponse();
        HttpServletResponse oResp = request.getHttpResponse();
        //
        try {
            wResp.moveDataToRealResponse(oResp);
            wrapRequest.moveDataToRealRequest(request);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        //
    }

}

